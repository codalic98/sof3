﻿namespace Server.DTOs
{
    public class UserCheckDTO
    {
        public long UserId { get; set; }
        public long RoleId { get; set; }
    }
}
