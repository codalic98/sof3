﻿namespace Server.Enums
{
    public enum SortValues
    {
        Name, 
        EnergyInKwh, 
        StandByKwh
    }
}
