export const Roles=Object.freeze({
	ADMIN_ID:1,
	ADMIN_NAME:"admin",
	1:"admin",
	DISPATCHER_ID:2,
	DISPATCHER_NAME:"dispatcher",
	2:"dispatcher",
	PROSUMER_ID:3,
	PROSUMER_NAME:"prosumer",
	3:"prosumer",
	// GUEST_ID:4,
	// GUEST_NAME:"guest",
	// 4:"guest",
	SUPERADMIN_ID:5,
	SUPERADMIN_NAME:"superadmin",
	5:"superadmin"
});