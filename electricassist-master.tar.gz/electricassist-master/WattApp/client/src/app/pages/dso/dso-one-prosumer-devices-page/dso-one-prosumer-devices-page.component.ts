import { Component } from '@angular/core';

@Component({
  selector: 'app-dso-one-prosumer-devices-page',
  templateUrl: './dso-one-prosumer-devices-page.component.html',
  styleUrls: ['./dso-one-prosumer-devices-page.component.css']
})
export class DsoOneProsumerDevicesPageComponent {

}
